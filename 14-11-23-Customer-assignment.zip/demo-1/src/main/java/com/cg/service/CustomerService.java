package com.cg.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.repository.CustomerRepository;


@Service
@org.springframework.transaction.annotation.Transactional
public class CustomerService {

	@Autowired
	 private CustomerRepository repo;
	public List<Customer> listAll(){
		List<Customer> details=repo.findAll();
		System.out.println(details);
		return details;
		
	}

}
